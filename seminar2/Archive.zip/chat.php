<?php
$messages = file_get_contents('chat.txt');
echo $messages;
?>